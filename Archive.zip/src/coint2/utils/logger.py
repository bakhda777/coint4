"""Logger module for backward compatibility."""

from .logging_utils import get_logger

__all__ = ['get_logger']