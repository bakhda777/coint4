import numpy as np
import pandas as pd
import statsmodels.api as sm
import hashlib
from collections import OrderedDict
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque
from functools import lru_cache

from ..core import performance


@dataclass
class TradeState:
    """State of an active trade."""
    entry_date: pd.Timestamp
    entry_index: int
    entry_z: float
    entry_spread: float
    position_size: float
    stop_loss_z: float
    capital_at_risk_used: float  # Capital at risk when trade was opened
    entry_price_s1: float
    entry_price_s2: float
    beta: float


class PairBacktester:
    """Vectorized backtester for a single pair."""

    def __init__(
        self,
        pair_data: pd.DataFrame,
        rolling_window: int,
        z_threshold: float,
        z_exit: float = 0.0,
        commission_pct: float = 0.0,
        slippage_pct: float = 0.0,
        bid_ask_spread_pct_s1: float = 0.001,
        bid_ask_spread_pct_s2: float = 0.001,
        annualizing_factor: int = 365,
        capital_at_risk: float = 1.0,
        stop_loss_multiplier: float = 2.0,
        take_profit_multiplier: float = None,
        cooldown_periods: int = 0,
        wait_for_candle_close: bool = False,
        max_margin_usage: float = float("inf"),
        half_life: float | None = None,
        time_stop_multiplier: float | None = None,
    ) -> None:
        """Initialize backtester.

        Parameters
        ----------
        pair_data : pd.DataFrame
            DataFrame with two columns containing price series for the pair.
        rolling_window : int
            Window size for rolling parameter estimation.
        z_threshold : float
            Z-score absolute threshold for entry signals.
        z_exit : float
            Z-score absolute threshold for exit signals (default 0.0).
        commission_pct : float
            Commission percentage for trades.
        slippage_pct : float
            Slippage percentage for trades.
        bid_ask_spread_pct_s1 : float
            Bid-ask spread percentage for first instrument (default 0.001).
        bid_ask_spread_pct_s2 : float
            Bid-ask spread percentage for second instrument (default 0.001).
        cooldown_periods : int
            Number of periods to wait after closing position before re-entering.
        """
        self.pair_data = pair_data.copy()
        self.rolling_window = rolling_window
        self.z_threshold = z_threshold
        self.z_exit = z_exit
        self.cooldown_periods = cooldown_periods
        self.results: pd.DataFrame | None = None
        self.commission_pct = commission_pct
        self.slippage_pct = slippage_pct
        self.bid_ask_spread_pct_s1 = bid_ask_spread_pct_s1
        self.bid_ask_spread_pct_s2 = bid_ask_spread_pct_s2
        self.annualizing_factor = annualizing_factor
        self.capital_at_risk = capital_at_risk
        self.stop_loss_multiplier = stop_loss_multiplier
        self.take_profit_multiplier = take_profit_multiplier
        self.wait_for_candle_close = wait_for_candle_close
        self.max_margin_usage = max_margin_usage
        self.half_life = half_life
        self.time_stop_multiplier = time_stop_multiplier
        self.s1 = pair_data.columns[0]
        self.s2 = pair_data.columns[1]
        self.trades_log: list[dict] = []
        
        # FIXED: Use OrderedDict with fixed size limit for memory control
        self._ols_cache = OrderedDict()
        self._ols_cache_max_size = 1000  # Fixed limit for 15-minute data
        self._last_window_hash = None
        
        # Incremental backtesting functionality (fixes look-ahead bias)
        self.capital_at_risk_history: pd.Series = pd.Series(dtype=float)
        self.active_trade: Optional[TradeState] = None
        self.incremental_pnl: pd.Series = pd.Series(dtype=float)
        self.incremental_positions: pd.Series = pd.Series(dtype=float)
        self.incremental_trades: pd.Series = pd.Series(dtype=float)
        self.incremental_costs: pd.Series = pd.Series(dtype=float)
        self.cooldown_end_date: Optional[pd.Timestamp] = None
        self.incremental_trades_log: List[Dict] = []
        
        # Validate trading parameters
        self._validate_parameters()

    def _validate_parameters(self) -> None:
        """Validate trading parameters for logical consistency."""
        # Check data size vs rolling window
        if len(self.pair_data) < self.rolling_window + 2:
            raise ValueError(f"Data length ({len(self.pair_data)}) must be at least rolling_window + 2 ({self.rolling_window + 2})")
        
        # Check threshold consistency
        if self.z_threshold <= 0:
            raise ValueError("z_threshold must be positive")
        
        if self.z_exit < 0:
            raise ValueError("z_exit must be non-negative")
            
        if self.z_exit >= self.z_threshold:
            raise ValueError(f"z_exit ({self.z_exit}) must be less than z_threshold ({self.z_threshold}). "
                           "Current configuration will prevent all position entries.")
        
        # Check multipliers consistency
        if self.stop_loss_multiplier <= 0:
            raise ValueError("stop_loss_multiplier must be positive")
            
        if self.take_profit_multiplier is not None and self.take_profit_multiplier <= 0:
            raise ValueError("take_profit_multiplier must be positive")
            
        # FIXED: Corrected take_profit validation - it should be less than 1.0 for proper logic
        if (self.take_profit_multiplier is not None and
            self.take_profit_multiplier >= 1.0):
            raise ValueError(f"take_profit_multiplier ({self.take_profit_multiplier}) must be less than 1.0 "
                           "to ensure take-profit triggers before entry level.")
        
        # Check cost parameters
        if self.commission_pct < 0 or self.slippage_pct < 0:
            raise ValueError("Commission and slippage percentages must be non-negative")
            
        if self.bid_ask_spread_pct_s1 < 0 or self.bid_ask_spread_pct_s2 < 0:
            raise ValueError("Bid-ask spread percentages must be non-negative")
            
        # Check for unrealistically high trading costs (including bid-ask spread)
        total_cost_pct = (self.commission_pct + self.slippage_pct +
                         max(self.bid_ask_spread_pct_s1, self.bid_ask_spread_pct_s2))
        if total_cost_pct > 0.05:  # 5% - more reasonable limit
            raise ValueError(f"Total trading costs ({total_cost_pct:.4f}) exceed 5%. "
                           "This is likely unrealistic for most markets.")
        
        # Check rolling window reasonableness
        if self.rolling_window < 3:
            raise ValueError("rolling_window must be at least 3 for meaningful regression")
        
        if self.rolling_window > len(self.pair_data) // 2:
            raise ValueError(f"rolling_window ({self.rolling_window}) is too large relative to data size ({len(self.pair_data)})")
        
        # FIXED: Добавлена проверка на минимальное количество наблюдений для статистической значимости
        if self.rolling_window < 10:
            import warnings
            warnings.warn(f"rolling_window ({self.rolling_window}) is very small and may lead to unreliable statistics", 
                         UserWarning, stacklevel=2)
        
        # FIXED: Проверка на разумность временных параметров
        if (self.half_life is not None and self.time_stop_multiplier is not None and 
            self.half_life * self.time_stop_multiplier < 1.0):
            raise ValueError(f"time_stop_limit ({self.half_life * self.time_stop_multiplier}) is too small - should be at least 1 time unit")

    def _calculate_ols_with_cache(self, y_win: pd.Series, x_win: pd.Series) -> tuple[float, float, float]:
        """Calculate OLS regression with caching for optimization.
        
        FIXED: Improved cache management to prevent memory leaks and secure hashing.
        """
        # FIXED: Use secure hashing with hashlib instead of unsafe str() fallback
        y_array = y_win.values
        x_array = x_win.values
        
        # Create secure hash using hashlib
        try:
            # Primary method: use tobytes() for efficient hashing
            y_bytes = y_array.tobytes()
            x_bytes = x_array.tobytes()
            hash_input = y_bytes + x_bytes + str(len(y_array)).encode()
        except (AttributeError, ValueError):
            # FIXED: Secure fallback using hashlib instead of str()
            hash_input = (str(y_array.tolist()) + str(x_array.tolist())).encode()
        
        window_hash = hashlib.md5(hash_input).hexdigest()
        
        # Check if we have cached results for this window
        if window_hash in self._ols_cache:
            # FIXED: Move to end for LRU behavior
            self._ols_cache.move_to_end(window_hash)
            return self._ols_cache[window_hash]
        
        # Calculate OLS regression
        x_const = sm.add_constant(x_win)
        model = sm.OLS(y_win, x_const).fit()
        
        # FIXED: Check if model has enough parameters to avoid IndexError
        if len(model.params) < 2:
            # For degenerate cases (e.g., constant data), return default values
            beta = 0.0
            spread_win = y_win - beta * x_win
            mean = spread_win.mean()
            std = max(spread_win.std(), 1e-8)  # Avoid zero std
        else:
            beta = model.params.iloc[1]
            spread_win = y_win - beta * x_win
            mean = spread_win.mean()
            std = max(spread_win.std(), 1e-8)  # FIXED: Avoid zero std in all cases
        
        # Cache the results
        result = (beta, mean, std)
        
        # FIXED: Use fixed size LRU cache to prevent unlimited memory growth
        if len(self._ols_cache) >= self._ols_cache_max_size:
            # Remove oldest entry (LRU behavior)
            self._ols_cache.popitem(last=False)
        
        self._ols_cache[window_hash] = result
        return result

    def clear_ols_cache(self) -> None:
        """Clear the OLS cache to free memory."""
        self._ols_cache.clear()
        self._last_window_hash = None

    def get_ols_cache_info(self) -> dict:
        """Get information about OLS cache usage.
        
        Returns
        -------
        dict
            Dictionary containing cache size, max size, and hit rate information.
        """
        return {
            "current_size": len(self._ols_cache),
            "max_size": self._ols_cache_max_size,
            "usage_pct": (len(self._ols_cache) / self._ols_cache_max_size) * 100,
            "memory_efficient": len(self._ols_cache) < self._ols_cache_max_size
        }
    
    def _is_profitable_exit(self, current_pnl: float, position: float, price_s1: float, 
                           price_s2: float, beta: float) -> bool:
        """Check if exit would be profitable after accounting for closing costs.
        
        Args:
            current_pnl: Current unrealized PnL of the trade
            position: Current position size (size_s1)
            price_s1: Current price of asset 1
            price_s2: Current price of asset 2
            beta: Current hedge ratio
            
        Returns:
            bool: True if exit would be profitable after costs
        """
        if position == 0:
            return True
            
        # Calculate closing costs
        position_s2 = -position * beta
        notional_s1 = abs(position * price_s1)
        notional_s2 = abs(position_s2 * price_s2)
        
        closing_commission = (notional_s1 + notional_s2) * self.commission_pct
        closing_slippage = (notional_s1 + notional_s2) * self.slippage_pct
        closing_bid_ask = (notional_s1 * self.bid_ask_spread_pct_s1 + 
                          notional_s2 * self.bid_ask_spread_pct_s2)
        
        total_closing_costs = closing_commission + closing_slippage + closing_bid_ask
        
        # Exit is profitable if current PnL exceeds closing costs
        return current_pnl > total_closing_costs

    def _calculate_position_size(self, entry_z: float, spread_curr: float, mean: float,
                               std: float, beta: float, price_s1: float, price_s2: float) -> float:
        """Calculate position size based on risk management parameters.
        
        FIXED: Added minimum risk_per_unit threshold to prevent excessive position sizes
        when spread is very close to stop loss.
        ENHANCED: Account for trading costs when calculating thresholds.
        """
        EPSILON = 1e-8
        
        stop_loss_z = float(np.sign(entry_z) * self.stop_loss_multiplier)
        stop_loss_price = mean + stop_loss_z * std
        risk_per_unit_raw = abs(spread_curr - stop_loss_price)
        trade_value = price_s1 + abs(beta) * price_s2
        
        # Calculate round-turn trading costs per unit
        # Round-turn = open + close, so 2x the one-way costs
        round_turn_commission_rate = 2 * (self.commission_pct + self.slippage_pct + 
                                         (self.bid_ask_spread_pct_s1 + self.bid_ask_spread_pct_s2) / 2)
        round_turn_cost_per_unit = trade_value * round_turn_commission_rate
        
        # Ensure minimum profit target is 2-3x round-turn costs
        min_profit_multiplier = 2.5  # 2.5x round-turn costs as minimum
        min_risk_per_unit_costs = min_profit_multiplier * round_turn_cost_per_unit
        
        # FIXED: Prevent excessive position sizes by enforcing minimum risk per unit
        # When risk_per_unit is too small, position size becomes dangerously large
        min_risk_per_unit_volatility = 0.1 * std  # Use 10% of volatility as minimum risk
        min_risk_per_unit = max(risk_per_unit_raw, min_risk_per_unit_costs, 
                               min_risk_per_unit_volatility, EPSILON)
        risk_per_unit = min_risk_per_unit
        
        # Use consistent epsilon protection for division by zero with stricter checks
        size_risk = self.capital_at_risk / risk_per_unit if risk_per_unit > EPSILON and np.isfinite(risk_per_unit) else 0.0
        size_value = self.capital_at_risk / trade_value if trade_value > EPSILON and np.isfinite(trade_value) else 0.0
        
        # Margin limit calculation with proper epsilon protection
        if np.isfinite(self.max_margin_usage) and trade_value > EPSILON:
            margin_limit = self.capital_at_risk * self.max_margin_usage / trade_value
        else:
            margin_limit = float('inf')
        
        return min(size_risk, size_value, margin_limit)

    def _calculate_trade_duration(self, current_time, entry_time, current_index: int, entry_index: int) -> float:
        """Calculate trade duration with consistent time units.
        
        FIXED: Унифицированная обработка времени - всегда возвращаем часы.
        """
        try:
            if isinstance(current_time, pd.Timestamp) and isinstance(entry_time, pd.Timestamp):
                # Return duration in hours for datetime indices
                return (current_time - entry_time).total_seconds() / 3600.0
            elif hasattr(current_time, '__sub__') and hasattr(entry_time, '__sub__'):
                # Try to calculate difference for other time-like objects
                diff = current_time - entry_time
                if hasattr(diff, 'total_seconds'):
                    return diff.total_seconds() / 3600.0
                else:
                    # FIXED: Для числовых индексов предполагаем 15-минутные данные
                    # Это обеспечивает консистентность с time_stop_multiplier
                    return float(diff) * 0.25  # 1 период = 15 минут = 0.25 часа
            else:
                # FIXED: Для non-datetime индексов возвращаем периоды в часах (15-минутные данные)
                return float(current_index - entry_index) * 0.25
        except (TypeError, AttributeError, ValueError):
            # FIXED: Enhanced fallback with better error handling (15-минутные данные)
            return float(current_index - entry_index) * 0.25

    def _enter_position(self, df: pd.DataFrame, i: int, signal: int, z_curr: float,
                       spread_curr: float, mean: float, std: float, beta: float) -> float:
        """Enter a new position with unified logic.
        
        FIXED: Extracted method to eliminate code duplication in position entry.
        """
        price_s1 = df["y"].iat[i]
        price_s2 = df["x"].iat[i]
        size = self._calculate_position_size(z_curr, spread_curr, mean, std, beta, price_s1, price_s2)
        new_position = signal * size

        # Log entry details
        df.loc[df.index[i], "entry_price_s1"] = price_s1
        df.loc[df.index[i], "entry_price_s2"] = price_s2
        df.loc[df.index[i], "entry_z"] = z_curr
        
        # FIXED: Unified time handling for entry date with proper dtype handling
        if isinstance(df.index, pd.DatetimeIndex):
            df.loc[df.index[i], "entry_date"] = df.index[i]
        else:
            df.loc[df.index[i], "entry_date"] = float(i)
            
        return new_position

    def _calculate_trading_costs(self, position_s1_change: float, position_s2_change: float,
                               price_s1: float, price_s2: float) -> tuple[float, float, float, float]:
        """Calculate detailed trading costs with full breakdown.
        
        FIXED: Унифицированный расчет издержек с полной детализацией.
        
        Returns:
            tuple: (commission_costs, slippage_costs, bid_ask_costs, total_costs)
        """
        notional_change_s1 = abs(position_s1_change * price_s1)
        notional_change_s2 = abs(position_s2_change * price_s2)
        
        # Детальный расчет всех компонентов издержек
        commission_costs = (notional_change_s1 + notional_change_s2) * self.commission_pct
        slippage_costs = (notional_change_s1 + notional_change_s2) * self.slippage_pct
        bid_ask_costs = (notional_change_s1 * self.bid_ask_spread_pct_s1 + 
                        notional_change_s2 * self.bid_ask_spread_pct_s2)
        total_costs = commission_costs + slippage_costs + bid_ask_costs
        
        return commission_costs, slippage_costs, bid_ask_costs, total_costs

    def _log_exit(self, df: pd.DataFrame, i: int, z_curr: float, exit_reason: str,
                  entry_datetime, entry_index: int) -> None:
        """FIXED: Extracted method to eliminate code duplication in exit logging."""
        df.loc[df.index[i], "exit_reason"] = exit_reason
        df.loc[df.index[i], "exit_price_s1"] = df.loc[df.index[i], "y"]
        df.loc[df.index[i], "exit_price_s2"] = df.loc[df.index[i], "x"]
        df.loc[df.index[i], "exit_z"] = z_curr
        
        # Calculate trade duration with unified time handling
        if entry_datetime is not None:
            df.loc[df.index[i], "trade_duration"] = self._calculate_trade_duration(
                df.index[i], entry_datetime, i, entry_index
            )

    def run(self) -> None:
        """Run backtest and store results in ``self.results``."""
        if self.pair_data.empty or len(self.pair_data.columns) < 2:
            self.results = pd.DataFrame(
                columns=["spread", "z_score", "position", "pnl", "cumulative_pnl"]
            )
            return

        # Переименовываем столбцы для удобства
        df = self.pair_data.rename(
            columns={
                self.pair_data.columns[0]: "y",
                self.pair_data.columns[1]: "x",
            }
        ).copy()

        # Prepare columns for rolling parameters
        df["beta"] = np.nan
        df["mean"] = np.nan
        df["std"] = np.nan
        df["spread"] = np.nan
        df["z_score"] = np.nan

        # FIXED: Use iloc for better performance and avoid potential indexing issues
        for i in range(self.rolling_window, len(df)):
            # FIXED: More efficient window slicing using iloc
            y_win = df["y"].iloc[i - self.rolling_window : i]
            x_win = df["x"].iloc[i - self.rolling_window : i]
            
            # Use cached OLS calculation
            beta, mean, std = self._calculate_ols_with_cache(y_win, x_win)
            
            # FIXED: Более гибкая обработка низкой волатильности
            # Используем адаптивный порог на основе средних значений цен
            price_scale = max(df["y"].iloc[i-self.rolling_window:i].mean(), 
                             df["x"].iloc[i-self.rolling_window:i].mean())
            min_std_threshold = max(1e-6, price_scale * 1e-4)  # Адаптивный порог
            
            if std < min_std_threshold:
                continue  # Skip this iteration, leaving values as NaN
            
            current_spread = df["y"].iat[i] - beta * df["x"].iat[i]
            z = (current_spread - mean) / std
            
            # FIXED: Use iloc for more efficient assignment
            idx = df.index[i]
            df.loc[idx, "beta"] = beta
            df.loc[idx, "mean"] = mean
            df.loc[idx, "std"] = std
            df.loc[idx, "spread"] = current_spread
            df.loc[idx, "z_score"] = z

        # Инициализируем столбцы для результатов
        df["position"] = 0.0
        df["trades"] = 0.0
        df["pnl"] = 0.0
        df["costs"] = 0.0

        # Добавляем столбцы для расширенного логирования
        df["entry_price_s1"] = np.nan
        df["entry_price_s2"] = np.nan
        df["exit_price_s1"] = np.nan
        df["exit_price_s2"] = np.nan
        df["entry_z"] = np.nan
        df["exit_z"] = np.nan
        df["exit_reason"] = ""
        df["trade_duration"] = 0.0
        # FIXED: Use proper dtype for entry_date to avoid warnings
        if isinstance(df.index, pd.DatetimeIndex):
            df["entry_date"] = pd.NaT
        else:
            df["entry_date"] = np.nan
        
        # Enhanced cost tracking columns
        df["commission_costs"] = 0.0
        df["slippage_costs"] = 0.0
        df["bid_ask_costs"] = 0.0
        df["impact_costs"] = 0.0

        total_cost_pct = self.commission_pct + self.slippage_pct

        position = 0.0
        entry_z = 0.0
        stop_loss_z = 0.0
        cooldown_remaining = 0  # Tracks remaining cooldown periods

        # Вынесем get_loc вычисления из цикла для оптимизации
        position_col_idx = df.columns.get_loc("position")
        trades_col_idx = df.columns.get_loc("trades")
        costs_col_idx = df.columns.get_loc("costs")
        pnl_col_idx = df.columns.get_loc("pnl")

        # Variables for detailed trade logging
        entry_datetime = None
        entry_spread = 0.0
        entry_position_size = 0.0
        entry_index = 0
        current_trade_pnl = 0.0

        for i in range(1, len(df)):
            if (
                pd.isna(df["spread"].iat[i])
                or pd.isna(df["spread"].iat[i - 1])
                or pd.isna(df["z_score"].iat[i])
            ):
                df.iat[i, position_col_idx] = position
                df.iat[i, trades_col_idx] = 0.0
                df.iat[i, costs_col_idx] = 0.0
                df.iat[i, pnl_col_idx] = 0.0
                continue

            beta = df["beta"].iat[i]
            mean = df["mean"].iat[i]
            std = df["std"].iat[i]
            spread_prev = df["spread"].iat[i - 1]
            spread_curr = df["spread"].iat[i]
            z_curr = df["z_score"].iat[i]

            # Calculate PnL using individual asset returns: pnl = size_s1 * ΔP1 + size_s2 * ΔP2
            # where size_s2 = -beta * size_s1
            price_s1_curr = df["y"].iat[i]
            price_s2_curr = df["x"].iat[i]
            price_s1_prev = df["y"].iat[i - 1]
            price_s2_prev = df["x"].iat[i - 1]
            
            delta_p1 = price_s1_curr - price_s1_prev
            delta_p2 = price_s2_curr - price_s2_prev
            
            # position represents size_s1, size_s2 = -beta * size_s1
            beta = df["beta"].iat[i]
            size_s1 = position
            size_s2 = -beta * size_s1
            
            pnl = size_s1 * delta_p1 + size_s2 * delta_p2

            new_position = position

            # FIXED: Time-based stop-loss с унифицированными единицами времени
            if (
                position != 0
                and self.half_life is not None
                and self.time_stop_multiplier is not None
                and entry_datetime is not None
            ):
                # Используем унифицированную функцию расчета времени (в часах)
                trade_duration_hours = self._calculate_trade_duration(
                    df.index[i], entry_datetime, i, entry_index
                )
                # half_life предполагается в днях, конвертируем в часы
                time_stop_limit_hours = self.half_life * 24 * self.time_stop_multiplier
                if trade_duration_hours >= time_stop_limit_hours:
                    new_position = 0.0
                    cooldown_remaining = self.cooldown_periods
                    # FIXED: Use extracted _log_exit method
                    self._log_exit(df, i, z_curr, 'time_stop', entry_datetime, entry_index)

            # Уменьшаем cooldown счетчик
            if cooldown_remaining > 0:
                cooldown_remaining -= 1

            # Закрытие позиций в конце теста для чистоты метрик
            if i == len(df) - 1 and position != 0:
                new_position = 0.0  # Форс-закрытие в последнем периоде
                cooldown_remaining = self.cooldown_periods
                # FIXED: Use extracted _log_exit method
                self._log_exit(df, i, z_curr, "end_of_test", entry_datetime, entry_index)
            # Стоп-лосс выходы
            elif position > 0 and z_curr <= stop_loss_z:
                new_position = 0.0
                cooldown_remaining = self.cooldown_periods
                # FIXED: Use extracted _log_exit method
                self._log_exit(df, i, z_curr, "stop_loss", entry_datetime, entry_index)
            elif position < 0 and z_curr >= stop_loss_z:
                new_position = 0.0
                cooldown_remaining = self.cooldown_periods
                # FIXED: Use extracted _log_exit method
                self._log_exit(df, i, z_curr, "stop_loss", entry_datetime, entry_index)
            # ENHANCED: Take-profit логика с учетом комиссий
            # Выход при движении z-score к нулю, но только если прибыль покрывает комиссии
            elif (
                self.take_profit_multiplier is not None
                and position != 0
                and abs(z_curr) <= abs(entry_z) * self.take_profit_multiplier
                and self._is_profitable_exit(current_trade_pnl, position, price_s1_curr, price_s2_curr, beta)
            ):
                new_position = 0.0
                cooldown_remaining = self.cooldown_periods
                # FIXED: Use extracted _log_exit method
                self._log_exit(df, i, z_curr, "take_profit", entry_datetime, entry_index)
            # Z-score exit: закрываем позицию если z-score вернулся к заданному уровню
            elif position != 0 and abs(z_curr) <= self.z_exit:
                new_position = 0.0
                cooldown_remaining = self.cooldown_periods
                # FIXED: Use extracted _log_exit method
                self._log_exit(df, i, z_curr, "z_exit", entry_datetime, entry_index)

            # Проверяем сигналы входа только если не в последнем периоде и не в cooldown
            if i < len(df) - 1 and cooldown_remaining == 0:
                signal = 0
                if z_curr > self.z_threshold:
                    signal = -1
                elif z_curr < -self.z_threshold:
                    signal = 1

                z_prev = df["z_score"].iat[i - 1]
                long_confirmation = (signal == 1) and (z_curr > z_prev)
                short_confirmation = (signal == -1) and (z_curr < z_prev)

                # FIXED: Extracted position entry logic to reduce duplication
                if (new_position == 0 and (long_confirmation or short_confirmation)) or (
                    new_position != 0
                    and (long_confirmation or short_confirmation)
                    and np.sign(new_position) != signal
                ):
                    new_position = self._enter_position(
                        df, i, signal, z_curr, spread_curr, mean, std, beta
                    )
                    entry_z = z_curr
                    stop_loss_z = float(np.sign(entry_z) * self.stop_loss_multiplier)

            # FIXED: Optimized DataFrame operations - calculate values once to avoid redundant operations
            price_s1 = df["y"].iat[i]
            price_s2 = df["x"].iat[i]
            trade_value = price_s1 + abs(beta) * price_s2
            
            # Note: Margin limit is now handled in _calculate_position_size method

            trades = abs(new_position - position)
            position_s1_change = new_position - position
            position_s2_change = -new_position * beta - (-position * beta)

            # Complete trading cost calculation including bid-ask spread
            notional_change_s1 = abs(position_s1_change * price_s1)
            notional_change_s2 = abs(position_s2_change * price_s2)
            
            # Calculate all cost components
            commission_costs = (notional_change_s1 + notional_change_s2) * self.commission_pct
            slippage_costs = (notional_change_s1 + notional_change_s2) * self.slippage_pct
            bid_ask_costs = (notional_change_s1 * self.bid_ask_spread_pct_s1 + 
                           notional_change_s2 * self.bid_ask_spread_pct_s2)
            
            total_costs = commission_costs + slippage_costs + bid_ask_costs

            # PnL after accounting for trading costs
            step_pnl = pnl - total_costs

            # 2. Обновляем основной DataFrame с детализированными издержками
            df.iat[i, position_col_idx] = new_position
            df.iat[i, trades_col_idx] = trades
            df.iat[i, costs_col_idx] = total_costs
            df.iat[i, pnl_col_idx] = step_pnl
            
            # Store detailed cost breakdown
            commission_col_idx = df.columns.get_loc("commission_costs")
            slippage_col_idx = df.columns.get_loc("slippage_costs")
            bid_ask_col_idx = df.columns.get_loc("bid_ask_costs")
            impact_col_idx = df.columns.get_loc("impact_costs")
            
            df.iat[i, commission_col_idx] = commission_costs
            df.iat[i, slippage_col_idx] = slippage_costs
            df.iat[i, bid_ask_col_idx] = bid_ask_costs
            df.iat[i, impact_col_idx] = 0.0   # Not implemented in this model

            # 3. Накапливаем PnL для детального лога (из версии codex)
            # Update trade PnL accumulator if a trade is open
            if position != 0 or (position == 0 and new_position != 0):
                current_trade_pnl += step_pnl

            # Handle entry logging
            if position == 0 and new_position != 0:
                entry_datetime = df.index[i]
                entry_spread = spread_curr
                entry_position_size = new_position
                entry_index = i
            # Handle exit logging
            if position != 0 and new_position == 0 and entry_datetime is not None:
                exit_datetime = df.index[i]
                # FIXED: Unified time handling with consistent units
                duration_hours = self._calculate_trade_duration(
                    exit_datetime, entry_datetime, i, entry_index
                )

                trade_info = {
                    "pair": f"{self.s1}-{self.s2}",
                    "entry_datetime": entry_datetime,
                    "exit_datetime": exit_datetime,
                    "position_type": "long" if entry_position_size > 0 else "short",
                    "entry_price_spread": entry_spread,
                    "exit_price_spread": spread_curr,
                    "pnl": current_trade_pnl,
                    "exit_reason": df.loc[df.index[i], "exit_reason"],
                    "trade_duration_hours": duration_hours,
                }
                self.trades_log.append(trade_info)

                # Сбрасываем счетчики для следующей сделки
                current_trade_pnl = 0.0
                entry_datetime = None
                entry_spread = 0.0
                entry_position_size = 0.0

            position = new_position

        df["cumulative_pnl"] = df["pnl"].cumsum()

        self.results = df

    def get_results(self) -> dict:
        if self.results is None:
            raise ValueError("Backtest not yet run")

        return {
            "spread": self.results["spread"],
            "z_score": self.results["z_score"],
            "position": self.results["position"],
            "trades": self.results["trades"],
            "costs": self.results["costs"],
            "pnl": self.results["pnl"],
            "cumulative_pnl": self.results["cumulative_pnl"],
            "trades_log": self.trades_log,
            # Enhanced cost breakdown
            "commission_costs": self.results["commission_costs"],
            "slippage_costs": self.results["slippage_costs"],
            "bid_ask_costs": self.results["bid_ask_costs"],
            "impact_costs": self.results["impact_costs"],
            # Price and regression data for PnL verification
            "y": self.results["y"],
            "x": self.results["x"],
            "beta": self.results["beta"],
        }

    def get_performance_metrics(self) -> dict:
        if self.results is None or self.results.empty:
            raise ValueError("Backtest has not been run or produced no results")

        pnl = self.results["pnl"].dropna()
        cum_pnl = self.results["cumulative_pnl"].dropna()

        # Если после dropna ничего не осталось, возвращаем нулевые метрики
        if pnl.empty:
            return {
                "sharpe_ratio": 0.0,
                "max_drawdown": 0.0,
                "total_pnl": 0.0,
                "win_rate": 0.0,
                "expectancy": 0.0,
                "kelly_criterion": 0.0,
            }

        # FIXED: Правильный расчет Sharpe Ratio - передаем доходности, а не PnL
        # Конвертируем PnL в доходности относительно capital_at_risk
        returns = pnl / self.capital_at_risk
        sharpe = performance.sharpe_ratio(returns, self.annualizing_factor)
        
        # Calculate new metrics
        win_rate_val = performance.win_rate(pnl)
        expectancy_val = performance.expectancy(pnl)
        kelly_val = performance.kelly_criterion(pnl)

        return {
            "sharpe_ratio": 0.0 if np.isnan(sharpe) else sharpe,
            "max_drawdown": performance.max_drawdown(cum_pnl),
            "total_pnl": cum_pnl.iloc[-1] if not cum_pnl.empty else 0.0,
            "win_rate": win_rate_val,
            "expectancy": expectancy_val,
            "kelly_criterion": kelly_val,
        }

    # Incremental backtesting methods (fixes look-ahead bias)
    def set_capital_at_risk(self, date: pd.Timestamp, capital: float) -> None:
        """Set capital at risk for a specific date.
        
        This method should be called before processing each day's data
        to ensure the correct capital amount is used for position sizing.
        """
        self.capital_at_risk_history[date] = capital
        
    def get_capital_at_risk_for_date(self, date: pd.Timestamp) -> float:
        """Get the capital at risk that was available on a specific date."""
        if date in self.capital_at_risk_history:
            return self.capital_at_risk_history[date]
        
        # If exact date not found, use the most recent available
        available_dates = self.capital_at_risk_history.index
        if len(available_dates) == 0:
            return self.capital_at_risk  # Fallback to initial value
            
        recent_dates = available_dates[available_dates <= date]
        if len(recent_dates) > 0:
            return self.capital_at_risk_history[recent_dates[-1]]
        else:
            return self.capital_at_risk  # Fallback to initial value
             
    def process_single_period(self, date: pd.Timestamp, price_s1: float, price_s2: float) -> Dict:
        """Process a single time period incrementally.
        
        This method fixes look-ahead bias by using only capital available at trade entry time.
        
        Returns:
            Dict with keys: position, trade, pnl, costs, trade_opened, trade_closed
        """
        # Ensure we have enough historical data
        if len(self.pair_data) < self.rolling_window + 1:
            return {
                'position': 0.0,
                'trade': 0.0, 
                'pnl': 0.0,
                'costs': 0.0,
                'trade_opened': False,
                'trade_closed': False
            }
            
        # Calculate current market parameters
        recent_data = self.pair_data.tail(self.rolling_window)
        if len(recent_data) < self.rolling_window:
            return {
                'position': 0.0,
                'trade': 0.0,
                'pnl': 0.0, 
                'costs': 0.0,
                'trade_opened': False,
                'trade_closed': False
            }
            
        y_win = recent_data.iloc[:, 0]
        x_win = recent_data.iloc[:, 1]
        
        try:
            beta, mean, std = self._calculate_ols_with_cache(y_win, x_win)
        except (ValueError, np.linalg.LinAlgError):
            return {
                'position': 0.0,
                'trade': 0.0,
                'pnl': 0.0,
                'costs': 0.0, 
                'trade_opened': False,
                'trade_closed': False
            }
            
        # Check for valid parameters
        if not (np.isfinite(beta) and np.isfinite(mean) and np.isfinite(std) and std > 1e-6):
            return {
                'position': 0.0,
                'trade': 0.0,
                'pnl': 0.0,
                'costs': 0.0,
                'trade_opened': False, 
                'trade_closed': False
            }
            
        current_spread = price_s1 - beta * price_s2
        z_score = (current_spread - mean) / std
        
        # Initialize result
        result = {
            'position': 0.0,
            'trade': 0.0,
            'pnl': 0.0,
            'costs': 0.0,
            'trade_opened': False,
            'trade_closed': False,
            'z_score': z_score,
            'spread': current_spread,
            'beta': beta,
            'mean': mean,
            'std': std
        }
        
        # Calculate P&L if we have an active trade
        if self.active_trade is not None:
            prev_spread = self.active_trade.entry_spread
            if date in self.incremental_pnl.index and len(self.incremental_pnl) > 0:
                # Get previous spread from the last available data
                prev_data = self.pair_data.iloc[-2] if len(self.pair_data) >= 2 else self.pair_data.iloc[-1]
                prev_spread = prev_data.iloc[0] - self.active_trade.beta * prev_data.iloc[1]
                
            # Calculate PnL using individual asset returns: pnl = size_s1 * ΔP1 + size_s2 * ΔP2
            # where size_s2 = -beta * size_s1
            delta_p1 = price_s1 - self.active_trade.entry_price_s1
            delta_p2 = price_s2 - self.active_trade.entry_price_s2
            
            size_s1 = self.active_trade.position_size
            size_s2 = -self.active_trade.beta * size_s1
            
            pnl = size_s1 * delta_p1 + size_s2 * delta_p2
            result['pnl'] = pnl
            result['position'] = self.active_trade.position_size
            
        # Check exit conditions
        trade_closed = False
        if self.active_trade is not None:
            # Stop loss
            if ((self.active_trade.position_size > 0 and z_score <= self.active_trade.stop_loss_z) or
                (self.active_trade.position_size < 0 and z_score >= self.active_trade.stop_loss_z)):
                self._close_trade(date, z_score, 'stop_loss')
                trade_closed = True
                result['trade_closed'] = True
                
            # Take profit
            elif (self.take_profit_multiplier is not None and
                  abs(z_score) <= abs(self.active_trade.entry_z) * self.take_profit_multiplier):
                self._close_trade(date, z_score, 'take_profit')
                trade_closed = True
                result['trade_closed'] = True
                
            # Z-score exit
            elif abs(z_score) <= self.z_exit:
                self._close_trade(date, z_score, 'z_exit')
                trade_closed = True
                result['trade_closed'] = True
                
            # Time stop
            elif (self.half_life is not None and self.time_stop_multiplier is not None):
                trade_duration_hours = (date - self.active_trade.entry_date).total_seconds() / 3600.0
                time_stop_limit_hours = self.half_life * 24 * self.time_stop_multiplier
                if trade_duration_hours >= time_stop_limit_hours:
                    self._close_trade(date, z_score, 'time_stop')
                    trade_closed = True
                    result['trade_closed'] = True
                    
        # Check entry conditions (only if no active trade and not in cooldown)
        if (self.active_trade is None and 
            (self.cooldown_end_date is None or date > self.cooldown_end_date)):
            
            signal = 0
            if z_score > self.z_threshold:
                signal = -1
            elif z_score < -self.z_threshold:
                signal = 1
                
            if signal != 0:
                # Get capital at risk for this specific date
                capital_for_trade = self.get_capital_at_risk_for_date(date)
                
                # Calculate position size using capital available at trade entry
                old_capital = self.capital_at_risk
                self.capital_at_risk = capital_for_trade
                position_size = self._calculate_position_size(
                    z_score, current_spread, mean, std, beta, price_s1, price_s2
                )
                self.capital_at_risk = old_capital  # Restore original
                
                if position_size > 0:
                    self._open_trade(date, z_score, current_spread, signal * position_size,
                                   capital_for_trade, price_s1, price_s2, beta)
                    result['position'] = signal * position_size
                    result['trade'] = abs(signal * position_size)
                    result['trade_opened'] = True
                    
        # Update incremental series
        self.incremental_pnl[date] = result['pnl']
        self.incremental_positions[date] = result['position']
        self.incremental_trades[date] = result['trade']
        self.incremental_costs[date] = result['costs']
        
        return result
         
    def _open_trade(self, date: pd.Timestamp, entry_z: float, entry_spread: float,
                   position_size: float, capital_used: float, price_s1: float, 
                   price_s2: float, beta: float) -> None:
        """Open a new trade."""
        stop_loss_z = float(np.sign(entry_z) * self.stop_loss_multiplier)
        
        self.active_trade = TradeState(
            entry_date=date,
            entry_index=len(self.pair_data) - 1,
            entry_z=entry_z,
            entry_spread=entry_spread,
            position_size=position_size,
            stop_loss_z=stop_loss_z,
            capital_at_risk_used=capital_used,
            entry_price_s1=price_s1,
            entry_price_s2=price_s2,
            beta=beta
        )
        
        # Log trade opening
        self.incremental_trades_log.append({
            'action': 'open',
            'date': date,
            'entry_z': entry_z,
            'position_size': position_size,
            'capital_used': capital_used,
            'entry_price_s1': price_s1,
            'entry_price_s2': price_s2,
            'beta': beta
        })
        
    def _close_trade(self, date: pd.Timestamp, exit_z: float, exit_reason: str) -> None:
        """Close the active trade."""
        if self.active_trade is None:
            return
            
        # Log trade closing
        self.incremental_trades_log.append({
            'action': 'close',
            'date': date,
            'exit_z': exit_z,
            'exit_reason': exit_reason,
            'position_size': self.active_trade.position_size,
            'capital_used': self.active_trade.capital_at_risk_used,
            'entry_date': self.active_trade.entry_date
        })
        
        # Set cooldown
        if self.cooldown_periods > 0:
            # Assuming 15-minute data, calculate cooldown end date
            cooldown_timedelta = pd.Timedelta(minutes=15 * self.cooldown_periods)
            self.cooldown_end_date = date + cooldown_timedelta
            
        self.active_trade = None
        
    def get_incremental_results(self) -> Dict:
        """Get results from incremental processing."""
        total_pnl = self.incremental_pnl.sum() if len(self.incremental_pnl) > 0 else 0.0
        trade_count = len([t for t in self.incremental_trades_log if t['action'] == 'open'])
        
        return {
            'pnl': self.incremental_pnl,
            'position': self.incremental_positions,
            'trades': self.incremental_trades,
            'costs': self.incremental_costs,
            'trades_log': self.incremental_trades_log,
            'total_pnl': total_pnl,
            'trade_count': trade_count
        }
        
    def reset_incremental_state(self) -> None:
        """Reset incremental state for a new backtest."""
        self.active_trade = None
        self.cooldown_end_date = None
        self.incremental_pnl = pd.Series(dtype=float)
        self.incremental_positions = pd.Series(dtype=float)
        self.incremental_trades = pd.Series(dtype=float)
        self.incremental_costs = pd.Series(dtype=float)
        self.incremental_trades_log = []
        self.capital_at_risk_history = pd.Series(dtype=float)
